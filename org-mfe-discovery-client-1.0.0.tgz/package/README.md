# @org/mfe-discovery-client

Enterprise-grade Microfrontend Discovery Client for Angular applications.

## Features

- Dynamic Microfrontend Resolution via Discovery Server
- Sub-Resource Integrity (SRI) Support
- Resilient Loading with Fallback Mechanisms
- Framework Agnostic Loader (optimized for Angular)

## Installation

```bash
npm install @org/mfe-discovery-client
```

## Usage

### Configuration

Initialize the client with your discovery service URL:

```typescript
import { HttpDiscoveryClient, MfeLoader } from '@org/mfe-discovery-client';

const discovery = new HttpDiscoveryClient('https://discovery.example.com', 'production');
export const mfeLoader = new MfeLoader(discovery);
```

### Loading a Remote Module

```typescript
import { mfeLoader } from './config';

const module = await mfeLoader.loadMfe<any>('payment-mfe', './PaymentModule');
```

### Angular Routing

Use the helper for lazy-loaded routes:

```typescript
import { mfeLazyRoute } from '@org/mfe-discovery-client';

const routes = [
  mfeLazyRoute(mfeLoader, 'payment-mfe', './PaymentModule')
];
```

## Development

```bash
# Build
npm run build

# Test
npm test

# Lint
npm run lint
```
